﻿# ========================================
# Local Azure CAPTURE TOOL - Startup Screen
# ========================================

Clear-Host

Write-Host @"
===========================================
          AZURE LOCAL INFO CAPTURES Session (ALICS)
===========================================
Welcome to the Azure Local Info Capture Session Tool!

Please choose an option:

  1) 📦 Run Solution SBE Update failure cause checker (Finds current Action Plan insances of interest. Pick an instance to pull Tasks logs.)
  2) 📜 Run ECE logs. ECE involved in orchestrating deployment, registration, updates, and lifecycle operations so.. likely some help (Collects c:\Observability\ECE and converts etl to txt.logs)
  3) 📜 Run Invoke-ClusterDiagnosticInfo (Collects logs from clusters and vms info)
  4) 📦 Run Device Gaurd Readiness or Credential gaurd readiness (Gaurd Policies need CIpolicy.p7b if enabling)
  5) 📦 Selective Log Collector. Pick Validation, Deployment Wac or all logs
  6) 📜 Remediate HCP Compliance not working. Manual setup HCP compliance (Placing HCP compliance files in C:\Users\Dell Folder. See user guide page 83)
  7) 📦 Report Generation for Cluster Kicked Off. Report is nice for Setting comparison. (HTML file should be coppied to the local management machine)
  8) 📦 Azure Local Log Collector. 16 Log Choices for varios failure points
  

===========================================
"@ -ForegroundColor Cyan

$choice = Read-Host "Enter your choice (1, 2 , 3, 4 , 5 or 6 or 7 or 8 )"

switch ($choice) {
    '1' {
        Write-Host "`nRunning SolutionSBE script..." -ForegroundColor Green
        # === Begin Solution.SBE1.1.txt script content ===
        # (your SolutionSBE script inserted here)
        # ========================================
        Write-Host "`n🔍 Gathering Azure Stack HCI Update Services, Processes, and Cluster Resources..." -ForegroundColor Cyan

        # Services
        $serviceFilter = @(
            '*AzureStack Agent Lifecycle Agent*',
            '*AzureStack UpdateService*',
            '*AzureStack HciOrchestratorService*',
            '*AzureStack File Copy Agent*',
            '*AzureStack Firewall Agent*',
            '*AzureStack Arc Extension Observability Agent*',
            '*AzureStack SyslogForwarder Agent*',
            '*AzureStack Trace Collector Agent*'
        )

        $services = Get-Service | Where-Object {
            foreach ($pattern in $serviceFilter) {
                if ($_.DisplayName -like $pattern) { return $true }
            }
        }

        Write-Host "`n🧩#1  Relevant Azure Stack Services:" -ForegroundColor Yellow
        $services | Sort-Object DisplayName | Format-Table Status, Name, DisplayName

        # Processes
        $processFilter = @(
            '*EnterpriseCloudEngine*',
            '*HciOrchestrator*',
            '*AzureStack.UpdateService*',
            '*AzureStack.Solution.Deploy*',
            '*AzureStack.Download.Monitor*',
            '*AzureStack.Infrastructure.Health*'
        )

        $processes = Get-Process | Where-Object {
            foreach ($pattern in $processFilter) {
                if ($_.Name -like $pattern) { return $true }
            }
        }

        Write-Host "`n🧠 #2 Active Update and Agent Processes:" -ForegroundColor Yellow
        $processes | Select-Object Id, ProcessName, CPU, StartTime | Format-Table -AutoSize

        # Cluster Resources
        if (Get-Command Get-ClusterResource -ErrorAction SilentlyContinue) {
            Write-Host "`n🔗 #3 Cluster Resources (if any):" -ForegroundColor Yellow
            Get-ClusterResource | Where-Object {
                $_.Name -match 'Agent|Extension|Update|Arc|HCI|Orchestrator'
            } | Format-Table Name, ResourceType, OwnerNode, State
        } else {
            Write-Host "`n[!] Not in a cluster context or Failover-Clustering module not available." -ForegroundColor Red
        }

        # Current Solution Updates
        Write-Host "`n📦 #4 Current Solution Updates in system:" -ForegroundColor Yellow
        Get-SolutionUpdate | Format-List ResourceId, State, Component, PackageType

        $currenttodo = Get-SolutionUpdate | Where-Object { $_.State -ne "Installed" }

        Write-Host "`n📋 #4.5  Current todo failed items :" -ForegroundColor Yellow
        $currenttodo | Format-List

        # Failed Solution Update Runs
        $failure = $currenttodo | Get-SolutionUpdateRun

        if ($failure) {
            Write-Host "`n📋 #5 List of Action Plan Resource IDs:" -ForegroundColor Yellow
            $failure.ResourceId | ForEach-Object { Write-Host $_ -ForegroundColor Cyan }

            $variablehere = Read-Host "`nEnter the ResourceId you want to lookup (copy from list above)"

            Write-Host "`nYou selected ResourceId: $variablehere" -ForegroundColor Green

            $TimeStamp = Get-Date -Format "yyMMdd_hhmmss"
            $OutputFile = "C:\Update_$failure_$TimeStamp.xml"
            (Get-ActionplanInstance -ActionplanInstanceId $variablehere).ProgressAsXml | Out-File -FilePath $OutputFile

            Write-Host "Output written to $OutputFile" -ForegroundColor Green
        } else {
            Write-Host "`n✔️ No failed Solution Update Runs found." -ForegroundColor Green
        }
    }
    '2' {
        Write-Host "`nRunning SaveLogs script..." -ForegroundColor Green
        # === Begin Savelogs.txt script content ===
        # (your SaveLogs script inserted here)
        # ========================================
        # You can call your existing savelogs.ps1 script file
        
# Set base temp folder
$BaseTempFolder = "C:\Temp"
if (-not (Test-Path $BaseTempFolder)) {
    New-Item -ItemType Directory -Path $BaseTempFolder
}

# ========================================
# 1. ECE Logs - ETL and Zips
# ========================================
Set-Location -Path "C:\Observability\ECE"
$mynames = Get-ChildItem -Recurse -Filter '*.etl' -ErrorAction 'SilentlyContinue'

# Netsh trace convert existing ETLs
$TimeStamp = Get-Date -Format "yyMMdd_hhmmss"
$OutputFile = Join-Path $BaseTempFolder ("ECELOGS_convert_" + $TimeStamp + ".txt")
netsh trace convert $mynames $OutputFile

# Handle ZIP files
$mynames2 = Get-ChildItem -Path "C:\Observability\ECE" -Recurse -Filter '*.zip' -ErrorAction SilentlyContinue

if ($mynames2.Count -gt 0) {
    Write-Host "There are some zip files here. This could take a while."
    $myread = Read-Host "You have $($mynames2.Count) zip files. Do you still want to unzip and extract ETL files? (y/n)"

    if ($myread -eq "y") {
        foreach ($zipFile in $mynames2) {
            Expand-Archive -Path $zipFile.FullName -DestinationPath $zipFile.DirectoryName -Force
        }

        $etlFiles = Get-ChildItem -Path "C:\Observability\ECE" -Recurse -Filter '*.etl' -ErrorAction SilentlyContinue

        foreach ($etl in $etlFiles) {
            if ($etl.DirectoryName -ne "C:\Observability\ECE") {
                $newName = [System.IO.Path]::GetFileNameWithoutExtension($etl.Name) + "_extracted" + [System.IO.Path]::GetExtension($etl.Name)
                $destinationPath = Join-Path "C:\Observability\ECE" $newName
                Copy-Item -Path $etl.FullName -Destination $destinationPath -Force
            }
        }

        Write-Host "Done extracting and copying ETL files!"

        # Re-convert after extracting
        $mynames = Get-ChildItem -Recurse -Filter '*.etl' -ErrorAction 'SilentlyContinue'
        $OutputFile = Join-Path $BaseTempFolder ("ECELOGS_convert_extracted_" + $TimeStamp + ".txt")
        netsh trace convert $mynames $OutputFile
    }
} else {
    Write-Host "No zip files found."
}

# Copy ECE logs to temp
Copy-Item -Path "C:\Observability\ECE\*" -Destination (Join-Path $BaseTempFolder "ECE") -Recurse -Force

# ========================================
# 2. OEM Diagnostics Logs
# ========================================
$FolderPath = "C:\Observability\OEMDiagnostics"
$Files = Get-ChildItem -Path $FolderPath -Filter "*AzureStack.Roles.OEMDiagnostics*" -File

foreach ($File in $Files) {
    Write-Host "Processing OEMDiagnostics file: $($File.FullName)"
    Get-ASEvent $File.FullName
}

$mylog3 = Get-ChildItem -Path $FolderPath | Where-Object { $_.Length -gt 1 } -ErrorAction SilentlyContinue
$mylog3put = Join-Path $BaseTempFolder ("OEMdiag_convert_" + $TimeStamp + ".txt")
Set-Location -Path $FolderPath
netsh trace convert $mylog3 $mylog3put

# Copy OEMDiagnostics logs
Copy-Item -Path "$FolderPath\*" -Destination (Join-Path $BaseTempFolder "OEMDiagnostics") -Recurse -Force
################################

##Cloud diagnostics

$FolderPath2 = "C:\Observability\CloudManagement"
$Files1 = Get-ChildItem -Path $FolderPath -Filter "*CloudManagement*" -File

foreach ($File1 in $Files1) {
    Write-Host "Processing CloudDiagnostics file: $($File1.FullName)"
    Get-ASEvent $File1.FullName
}

$mylog2 = Get-ChildItem -Path $FolderPath | Where-Object { $_.Length -gt 1 } -ErrorAction SilentlyContinue
$mylog2put = Join-Path $BaseTempFolder ("Clouddiag_convert_" + $TimeStamp + ".txt")
Set-Location -Path $FolderPath2
netsh trace convert $mylog2 $mylog2put

# Copy OEMDiagnostics logs
Copy-Item -Path "$FolderPath\*" -Destination (Join-Path $BaseTempFolder "Cloudiagnostics") -Recurse -Force


#################################

# ========================================
# 3. Copy Important MOC, SDP, ECE, MocArb logs
# ========================================
$AdditionalLogs = @(
    "C:\ProgramData\mochostagent\log",             # MoCHostAgent logs
    "C:\ProgramData\AzureStack\HCI\Log",            # ECE Logs
    "C:\ProgramData\Microsoft\AzureStack\SDP\log",  # SDP Logs
    "C:\ProgramData\Microsoft\AzureStack\UpdateService\Log", # Update Service
    "C:\ProgramData\SF\Log"                         # Service Fabric logs
)

foreach ($logPath in $AdditionalLogs) {
    if (Test-Path $logPath) {
        $folderName = Split-Path -Path $logPath -Leaf
        $destFolder = Join-Path $BaseTempFolder $folderName
        Copy-Item -Path "$logPath\*" -Destination $destFolder -Recurse -Force -ErrorAction SilentlyContinue
        Write-Host "Copied logs from $logPath"
    }
}

# ========================================
# 4. Export Event Logs related to Update Failures
# ========================================
Write-Host "Exporting Event Viewer logs for troubleshooting..."

$EventLogs = @(
    "Microsoft-AzureStack-HCI/Operational",
    "Microsoft-AzureStack-HCI/Solutions",
    "Microsoft-Windows-Cluster-Aware-Updating/Operational",
    "Microsoft-Windows-FailoverClustering/Operational",
    "Microsoft-ServiceFabric/Admin",
    "System",
    "Application"
)

foreach ($logName in $EventLogs) {
    try {
        $eventExportFile = Join-Path $BaseTempFolder ("EventLog_" + ($logName -replace '[\\/]', '_') + ".evtx")
        wevtutil epl "$logName" "$eventExportFile"
        Write-Host "Exported $logName"
    } catch {
        Write-Warning "Failed to export $logName. It may not exist."
    }
}

# ========================================
# 6. Extra Critical Logs Collection (MASLogs, NuGetStore, ClusterStorage)
# ========================================
Write-Host "Collecting extra critical logs..."
$BaseTempFolder = "c:\temp"

if (-not (Test-Path $BaseTempFolder)) {
    New-Item -ItemType Directory -Path $BaseTempFolder -Force
}


# Local folders
$ExtraPaths = @(
    "C:\maslogs",
    "C:\NuGetStore",
    "C:\Windows\Logs\CBS"
    "C:\ProgramData\GuestConfig"

)

foreach ($path in $ExtraPaths) {
    if (Test-Path $path) {
        $folderName = Split-Path -Path $path -Leaf
        $destFolder = Join-Path $BaseTempFolder $folderName
        Copy-Item -Path "$path\*" -Destination $destFolder -Recurse -Force -ErrorAction SilentlyContinue
        Write-Host "Copied $path"
    }
}

# Remote ClusterStorage share on local node
$LocalNode = $env:COMPUTERNAME
$ClusterShare = "\\$LocalNode\c$\ClusterStorage\Infrastructure_1\Shares\SU1_Infrastructure_1"

if (Test-Path $ClusterShare) {
    $ClusterShareDest = Join-Path $BaseTempFolder "ClusterStorage_SU1_Infrastructure_1"
    Copy-Item -Path "$ClusterShare\*" -Destination $ClusterShareDest -Recurse -Force -ErrorAction SilentlyContinue
    Write-Host "Copied Cluster Storage Share: $ClusterShare"
} else {
    Write-Warning "Cluster share $ClusterShare not reachable."
}



Write-Host "✅ All important logs have been collected into C:\Temp"





    }
    '3' {
        Write-Host "`nRunning Cluster Diagnostic Info collection..." -ForegroundColor Green
        $outputPath = "C:\temp\clusterdiagnosticinfo"
        if (-Not (Test-Path $outputPath)) {
            New-Item -ItemType Directory -Path $outputPath | Out-Null
        }
        Get-ClusterDiagnosticInfo -WriteToPath $outputPath
        Write-Host "`n✅ Cluster diagnostics saved to $outputPath" -ForegroundColor Cyan
    }	
	
	'4' {
        Write-Host "`nDevice Gaurd Credential Gaurd Hyper-v Protected Code Integrity..." -ForegroundColor Green
         
  

# Create output path and ensure C:\temp exists
$timestamp = Get-Date -Format "yyyy-MM-dd_HH-mm-ss"
$reportPath = "C:\temp\DG_credguard_HVCI_Report_$timestamp.txt"
if (-not (Test-Path "C:\temp")) { New-Item -Path "C:\temp" -ItemType Directory | Out-Null }

# Start capturing output
Start-Transcript -Path $reportPath -Force

function Run-DGReadiness {
    Write-Host "== Device Guard Readiness Tool ==" -ForegroundColor Cyan
    Write-Host "`nThis application will configure:"
    Write-Host "CG   = Credential Guard"
    Write-Host "DG   = Device Guard"
    Write-Host "HVCI = Hyper-V protected Code Integrity`n"

    $capabilitiesPath = "HKLM:\SYSTEM\CurrentControlSet\Control\DeviceGuard\Capabilities"
    $keys = @("CG_Capable", "DG_Capable", "HVCI_Capable")
    
    foreach ($key in $keys) {
        $value = Get-ItemProperty -Path $capabilitiesPath -Name $key -ErrorAction SilentlyContinue | Select-Object -ExpandProperty $key -ErrorAction SilentlyContinue
        switch ($value) {
            0 { $meaning = "Not possible to enable DG/CG/HVCI on this device" }
            1 { $meaning = "Capable but missing firmware/hardware/software for full qualifications" }
            2 { $meaning = "Fully compatible" }
            default { $meaning = "Value not found or unsupported" }
        }
        Write-Host "$key : $value ($meaning)"
    }

    Write-Host "`nEvaluating registry configuration consistency..."
    $expected = @{
        "HKLM:\SYSTEM\CurrentControlSet\Control\DeviceGuard" = @{
            "EnableVirtualizationBasedSecurity" = 1
            "RequirePlatformSecurityFeatures"   = 1
            "Locked"                            = 0
        }
        "HKLM:\SYSTEM\CurrentControlSet\Control\DeviceGuard\Scenarios\HypervisorEnforcedCodeIntegrity" = @{
            "Enabled" = 1
            "Locked"  = 0
        }
        "HKLM:\SYSTEM\CurrentControlSet\Control\Lsa" = @{
            "LsaCfgFlags" = 2
        }
    }

Write-host "These Registry Keys Will tell you if your Capable, Ready , Enabled Or Disabled! They are dumped first to compare to expected enabled values" -ForegroundColor Green
    foreach ($path in $expected.Keys) {
        foreach ($name in $expected[$path].Keys) {
            $expectedValue = $expected[$path][$name]
            $actualValue = Get-ItemProperty -Path $path -Name $name -ErrorAction SilentlyContinue | Select-Object -ExpandProperty $name -ErrorAction SilentlyContinue
            if ($actualValue -ne $null) {
                if ($actualValue -eq $expectedValue) {
                    Write-Host "[OK] $path\$name = $actualValue"
                } else {
                    Write-Host "[MISMATCH] $path\$name = $actualValue (Expected: $expectedValue)" -ForegroundColor Yellow
                }
            } else {
                Write-Host "[MISSING] $path\$name (Expected: $expectedValue)" -ForegroundColor Red
            }
        }
    }

    $action = Read-Host "`nEnter desired action: Capable / Ready / Enable / Disable"
    $target = Read-Host "Enter target: DG / CG / HVCI"
    $pathArg = ""

    if ($action -eq "Enable" -or $action -eq "Disable") {
        $sipolicyPath = Read-Host "Enter full path to sipolicy.p7b"
        if (-not (Test-Path $sipolicyPath)) {
            Write-Host "Invalid path provided. Exiting." -ForegroundColor Red
            return
        }
        $pathArg = "-Path `"$sipolicyPath`""
    }

    $cmd = ".\DG_Readiness.ps1 -$action -$target $pathArg"
    Write-Host "`nExecuting: $cmd" -ForegroundColor Cyan
    Invoke-Expression $cmd
}

Run-DGReadiness

Write-Host "`n✅ This Concludes this Tools Session. Have a Super Duper Day!" -ForegroundColor Cyan
Write-Host "`n✅ The Reboot Message is just a system warning. If you choose Capable or Ready then Nothing has been changed!!" -ForegroundColor Cyan

# Stop capturing output and inform user
Stop-Transcript
Write-Host "`n📄 Report saved to: $reportPath"
#Invoke-Item $reportPath     
$reader= read-Host "`n📄 Do you want to open the file: $reportPath"
If ($reader -notcontains "n") {Invoke-Item $reportPath}	
 
    }	
    '5' {
        Write-Host "`nRunning Log Collection Algorythem..." -ForegroundColor Green
        $outputPath = "C:\temp"
        if (-Not (Test-Path $outputPath)) {
            New-Item -ItemType Directory -Path $outputPath | Out-Null
        }
         



# Prompt for log collection type
Write-Host "`nSelect log collection type:"
Write-Host "1. WAC Logs"
Write-Host "2. Registration Failing"
Write-Host "3. Validation or Post Validation"
Write-Host "4. All Logs"
Write-Host "5. Cluster Sync Failure Only"
$choice = Read-Host "Enter your choice (1-5)"

$savePath = "C:\temp"
New-Item -ItemType Directory -Force -Path $savePath | Out-Null

Function Test-And-Copy {
    param ($remotePath, $destination, $hostname)

    #$sharePath = $remotePath.TrimStart("C:\").Replace("\", "$\")
   # $uncPath = "\\$hostname\$sharePath"

   $relativePath = $remotePath.Substring(3) # Strip "C:\"
$driveLetter = $remotePath.Substring(0,1) + "$"
$uncPath = "\\$hostname\$driveLetter\$relativePath"

    if (Test-Path $uncPath) {
        try {
            $files = Get-ChildItem -Path $uncPath -Recurse -Force -ErrorAction Stop
            if ($files.Count -gt 0) {
                Write-Host " Files found in: $uncPath"
                $target = Join-Path $destination ($hostname + "_" + ($remotePath -replace '[\\:\s]', '_'))
                Copy-Item -Path $uncPath -Destination $target -Recurse -Force -ErrorAction SilentlyContinue
                Write-Host " Copied logs to: $target"
            } else {
                Write-Warning "⚠ No files in path: $uncPath"
            }
        } catch {
            Write-Warning "Unable to enumerate or copy: $uncPath. $_"
        }
    } else {
        Write-Warning  "Path not found: $uncPath"
    }
}

# [Switch block remains the same from here forward]




switch ($choice) {
    '1' {
        $wachost = Read-Host "Enter WAC host name"
        Test-And-Copy -remotePath "C:\ProgramData\WindowsAdminCenter\Logs" -destination $savePath -hostname $wachost
        Test-And-Copy -remotePath "C:\Windows\ServiceProfiles\NetworkService\AppData\Local\Temp\generated\logs" -destination $savePath -hostname $wachost
    }

    '2' {
        $cluster = Read-Host "Enter Cluster Name"
        Get-ClusterNode -Cluster $cluster | ForEach-Object {
            $nodeName = $_.Name
            Test-And-Copy -remotePath "C:\Windows\System32\Bootstrap\Logs\AzStackHci.ArcConnection.Debug.log" -destination $savePath -hostname $nodeName
            Test-And-Copy -remotePath "C:\Windows\System32\Bootstrap\Logs\arcInstallLog.txt" -destination $savePath -hostname $nodeName
            Test-And-Copy -remotePath "C:\Windows\System32\Bootstrap\DiagnosticsHistory" -destination $savePath -hostname $nodeName
            Test-And-Copy -remotePath "C:\Windows\System32\Bootstrap\content_10.2503.0.3037" -destination $savePath -hostname $nodeName
        }
    }

    '3' {
        $cluster = Read-Host "Enter Cluster Name"
        Get-ClusterNode -Cluster $cluster | ForEach-Object {
            $nodeName = $_.Name
            Test-And-Copy -remotePath "C:\MASLogs" -destination $savePath -hostname $nodeName
            Test-And-Copy -remotePath "C:\ProgramData\Dell\UpdatePackage\log" -destination $savePath -hostname $nodeName
            Test-And-Copy -remotePath "C:\ProgramData\GuestConfig\arc_policy_logs" -destination $savePath -hostname $nodeName
            Test-And-Copy -remotePath "C:\ProgramData\GuestConfig\extension_logs" -destination $savePath -hostname $nodeName
            Test-And-Copy -remotePath "C:\CloudContent\MASLogs" -destination $savePath -hostname $nodeName
            Test-And-Copy -remotePath "C:\CloudDeployment\Logs" -destination $savePath -hostname $nodeName
        }
    }

    '4' {
        $cluster = Read-Host "Enter Cluster Name"
        $wachost = Read-Host "Enter WAC host name"

        Test-And-Copy -remotePath "C:\ProgramData\WindowsAdminCenter\Logs" -destination $savePath -hostname $wachost
        Test-And-Copy -remotePath "C:\Windows\ServiceProfiles\NetworkService\AppData\Local\Temp\generated\logs" -destination $savePath -hostname $wachost

        Get-ClusterNode -Cluster $cluster | ForEach-Object {
            $nodeName = $_.Name
            Test-And-Copy -remotePath "C:\Windows\System32\Bootstrap\Logs\AzStackHci.ArcConnection.Debug.log" -destination $savePath -hostname $nodeName
            Test-And-Copy -remotePath "C:\Windows\System32\Bootstrap\Logs\arcInstallLog.txt" -destination $savePath -hostname $nodeName
            Test-And-Copy -remotePath "C:\Windows\System32\Bootstrap\DiagnosticsHistory" -destination $savePath -hostname $nodeName
            Test-And-Copy -remotePath "C:\Windows\System32\Bootstrap\content_10.2503.0.3037" -destination $savePath -hostname $nodeName
        }

        Get-ClusterNode -Cluster $cluster | ForEach-Object {
            $nodeName = $_.Name
            Test-And-Copy -remotePath "C:\MASLogs" -destination $savePath -hostname $nodeName
            Test-And-Copy -remotePath "C:\ProgramData\Dell\UpdatePackage\log" -destination $savePath -hostname $nodeName
            Test-And-Copy -remotePath "C:\ProgramData\GuestConfig\arc_policy_logs" -destination $savePath -hostname $nodeName
            Test-And-Copy -remotePath "C:\ProgramData\GuestConfig\extension_logs" -destination $savePath -hostname $nodeName
            Test-And-Copy -remotePath "C:\CloudContent\MASLogs" -destination $savePath -hostname $nodeName
            Test-And-Copy -remotePath "C:\CloudDeployment\Logs" -destination $savePath -hostname $nodeName
        }
    }

    '5' {
        $AdditionalLogs = "Microsoft-Windows-Kernel-Boot/Operational","Microsoft-Windows-Kernel-IO/Operational","System","Application","Microsoft-Windows-WMI-Activity/Operational","Microsoft-Windows-Crypto-NCrypt/Operational","Microsoft-Windows-Crypto-DPAPI/Operational"
        $logNames = @("Microsoft-AzureStack-Hci/Admin", "Microsoft-AzureStack-Hci/Debug") + $AdditionalLogs
        $date = Get-Date
        $datestring = "{0}{1:d2}{2:d2}-{3:d2}{4:d2}" -f $date.year,$date.month,$date.day,$date.hour,$date.minute
        $logDir = Join-Path -Path (Get-Location) -ChildPath "AzsHci-Logs_$datestring"
        New-Item -ItemType Directory -Force -Path $logDir | Out-Null

        $s = {
            $path = Join-Path -Path $env:temp -ChildPath $env:computername
            Remove-Item $path -Recurse -Force -ErrorAction SilentlyContinue
            New-Item -Path $path -ItemType Directory | Out-Null
            $using:logNames | ForEach-Object {
                $basefilename = Join-Path -Path $path -ChildPath ($_.Replace("/", "-"))
                $filename = $basefilename + ".evtx"
                $evt = New-Object System.Diagnostics.Eventing.Reader.EventLogSession
                $evt.ExportLogAndMessages($_, 'LogName', "*", $filename)
                Get-WinEvent -LogName $_ -Oldest -ErrorAction SilentlyContinue | Format-Table -AutoSize -Wrap | Out-File "$basefilename.txt"
            }
            return $path
        }

        $jobs = @()
        $i = 0
        Get-ClusterNode | ForEach-Object {
            ++$i; $node = $_.Name
            $jobs += Start-Job -ScriptBlock {
                Write-Progress -Id $using:i -Activity "Collecting AzsHCI Logs" -Status "Node $using:node"
                $lognames = $using:logNames
                $session = New-PSSession -ComputerName $using:node
                $remotepath = Invoke-Command -Session $session -ScriptBlock ([scriptblock]::Create($using:s))
                Copy-Item -Path $remotepath -Destination $using:logDir -Recurse -FromSession $session -Force
                Remove-PSSession $session
            }
        }

        Receive-Job $jobs -Wait -AutoRemove -ErrorAction SilentlyContinue
        Compress-Archive $logDir -DestinationPath "$logDir.zip"
        Write-Host "Cluster sync logs zipped to: $logDir.zip"
    }

    Default {
        Write-Warning "Invalid choice. Exiting"
    }
}




    }
    '6' {  
    
    Write-Host "`nHCP Remediation. Copy files to C:\Users\Dell.." -ForegroundColor Green
   
Write-Host "`nHCP Remediation. Copy folders to C:\Users\Dell.." -ForegroundColor Green

# Define output path
$outputPath = "C:\Users\Dell"
if (-Not (Test-Path $outputPath)) {
    New-Item -ItemType Directory -Path $outputPath | Out-Null
}

# Determine the base directory
$scriptDir = if ($PSScriptRoot) { $PSScriptRoot } else { Get-Location }

# Set paths based on RuntimeFiles subfolder
$zipFilePath = Join-Path $scriptDir "RuntimeFiles\HCPRemediate.zip"
$unzipPath = Join-Path $scriptDir "RuntimeFiles\HCPRemediate"

# Unzip the file
if (Test-Path $zipFilePath) {
    Expand-Archive -Path $zipFilePath -DestinationPath $unzipPath -Force
    Write-Host "Unzipped HCPRemediate.zip to $unzipPath" -ForegroundColor Green
} else {
    Write-Host "Zip file not found: $zipFilePath" -ForegroundColor Red
    exit
}

# Copy the unzipped folder structure to the output directory
Get-ChildItem -Path $unzipPath -Directory | ForEach-Object {
    $source = $_.FullName
    $dest = Join-Path $outputPath $_.Name
    Copy-Item -Path $source -Destination $dest -Recurse -Force
}

Write-Host "Finished copying folders to $outputPath" -ForegroundColor Green
    
      }

    '7' {  
    
    Write-Host "`nRunning Report Collection for Cluster" -ForegroundColor Green
    $outputPath = "C:\Temp"
        if (-Not (Test-Path $outputPath)) {
            New-Item -ItemType Directory -Path $outputPath | Out-Null
        }
    
#.\Get-HyperVInventory-MultipleReports.ps1
& ".\Get-HyperVInventory-MultipleReports.ps1"
 
Write-Host "`nReport Collection Complete...." -ForegroundColor Green
    
      }

    '8' {
    
    
    


# ———— Launch in STA mode: powershell.exe -STA ————

# 1) Show date picker dialog and capture startDate
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

$form = New-Object System.Windows.Forms.Form
$form.Text            = 'Select Start Date'
$form.Size            = New-Object System.Drawing.Size(280,150)
$form.StartPosition   = 'CenterScreen'

$dtPicker = New-Object System.Windows.Forms.DateTimePicker
$dtPicker.Format      = 'Short'
$dtPicker.Width       = 200
$dtPicker.Location    = New-Object System.Drawing.Point(30,20)
$form.Controls.Add($dtPicker)

$cancel = New-Object System.Windows.Forms.Button
$cancel.Text          = 'Cancel'
$cancel.Width         = 80
$cancel.Location      = New-Object System.Drawing.Point(100,60)
$cancel.DialogResult  = [System.Windows.Forms.DialogResult]::Cancel
$form.Controls.Add($cancel)
$form.CancelButton    = $cancel

$dtPicker.Add_CloseUp({
    $form.DialogResult = [System.Windows.Forms.DialogResult]::OK
    $form.Close()
})

if ($form.ShowDialog() -ne [System.Windows.Forms.DialogResult]::OK) {
    Write-Warning "Date selection cancelled. Exiting script."; return
}

$startDate = $dtPicker.Value.Date
Write-Host "Start date set to (Start Date: $($startDate.ToString('yyyy-MM-dd'))" -ForegroundColor Cyan

# 2) Define menu items
$menuItems = @(
  'Collect Main logs Lifecycle'
  'Collect ALM agents logs'
  'Collect ARC agents logs'
  'Collect Bootstrap & Diagnostics logs'
  'Collect Deployment logs'
  'Collect OSupdate logs'
  'Collect Download Service logs'
  'Collect HCI Cloud Service logs'
  'Collect MOC Arb logs'
  'Collect ECE logs'
  'Collect Roles & Observability logs'
  'Collect Health Check logs'
  'Collect SDN Network logs'
  'Collect Middleware logs'
  'Collect LCM ECE Lite logs'
  'Health & Monitoring logs'
)

# 3) Define the actions for each option
$actions = @{}

$actions['1'] = {
    Write-Host "`n[Option 1] $($menuItems[0]) from (Start Date: $($startDate.ToString('yyyy-MM-dd')) to today..."
    $dest = "C:\Temp\ALM"; if (-not (Test-Path $dest)) { New-Item -Path $dest -ItemType Directory | Out-Null }
    $sources = @(
      "C:\Observability\ALM",
      "C:\Observability\ALMSystemAgents",
      @{ Path = "C:\MASLogs"; Filter = "AgentLifeCycleManager_*" }
    )
    foreach ($src in $sources) {
      if ($src -is [string]) {
        if (Test-Path $src) {
          Get-ChildItem -Path $src -Recurse -File -Include *.zip,*.log,*.etl |
            Where-Object LastWriteTime -ge $startDate |
            Copy-Item -Destination $dest -Force
        }
      } else {
        if (Test-Path $src.Path) {
          Get-ChildItem -Path $src.Path -Recurse -File -Filter $src.Filter |
            Where-Object LastWriteTime -ge $startDate |
            Copy-Item -Destination $dest -Force
        }
      }
    }
    Write-Host "`nDone! See $dest.`n"
}

$actions['2'] = {
    Write-Host "`n[Option 2] $($menuItems[1]) (Start Date: $($startDate.ToString('yyyy-MM-dd'))..."
    $dest = "C:\Temp\ALM agents"; if (-not (Test-Path $dest)) { New-Item -Path $dest -ItemType Directory | Out-Null }
    $agentSources = @(
      "C:\Observability\ALMSystemAgents\FileCopyAgent",
      "C:\Observability\ALMSystemAgents\FirewallAgent",
      "C:\Observability\ALMSystemAgents\Hypersync"
    )
    foreach ($src in $agentSources) {
      if (Test-Path $src) {
        Get-ChildItem -Path $src -Recurse -File -Include *.etl,*.zip |
          Where-Object LastWriteTime -ge $startDate |
          Copy-Item -Destination $dest -Force
      }
    }
    Write-Host "`nDone! See $dest.`n"
}

$actions['3'] = {
    Write-Host "`n[Option 3] $($menuItems[2]) from (Start Date: $($startDate.ToString('yyyy-MM-dd')) to today..."
    $dest = "C:\Temp\arc agents"; if (-not (Test-Path $dest)) { New-Item -Path $dest -ItemType Directory | Out-Null }
    $arcSources = @(
      "C:\ProgramData\AzureConnectedMachineAgent\Log\*",
      "C:\ProgramData\AzureConnectedMachineAgent\*Log",
      "C:\Windows\System32\Bootstrap\Logs\*",
      "C:\Windows\System32\Bootstrap\Logs\AzStackHci.ArcConnection.Debug.log\*.txt",
      "C:\ProgramData\GuestConfig\ext_mgr_logs\*",
      "C:\ProgramData\GuestConfig\arc_policy_logs\*",
      "C:\ProgramData\GuestConfig\extension_logs\*",
      "C:\ProgramData\GuestConfig\extension_reports\*"
    )
    foreach ($src in $arcSources) {
      Get-ChildItem -Path $src -Recurse -File -ErrorAction SilentlyContinue |
        Where-Object LastWriteTime -ge $startDate |
        Copy-Item -Destination $dest -Force
    }
    Write-Host "`nDone! See $dest.`n"
}

# … repeat for options 4 through 15 in the same pattern … #

$actions['16'] = {
    Write-Host "`n[Option 16] $($menuItems[15]) from (Start Date: $($startDate.ToString('yyyy-MM-dd'))to today..."
    $dest = "C:\Temp\health and monitoring"; if (-not (Test-Path $dest)) { New-Item -Path $dest -ItemType Directory | Out-Null }
    $hmSources = @(
      "C:\Observability\HealthAndMonitoring\Diagnostics\HealthAgent\CommonInfra\*.etl",
      "C:\Observability\HealthAndMonitoring\Diagnostics\HealthAgent\CommonInfra\*.zip",
      "C:\Observability\HealthAndMonitoring\Diagnostics\HealthAgent\*.etl"
    )
    foreach ($src in $hmSources) {
      Get-ChildItem -Path $src -Recurse -File -ErrorAction SilentlyContinue |
        Where-Object LastWriteTime -ge $startDate |
        Copy-Item -Destination $dest -Force
    }
    Write-Host "`nDone! See $dest.`n"
}

# 4) Function to show the menu
function Show-Menu {
    Clear-Host
    Write-Host "=== Main Menu (Start Date: $($startDate.ToString('yyyy-MM-dd'))) ===`n"
    for ($i = 0; $i -lt $menuItems.Count; $i++) {
        Write-Host (" {0}) {1}" -f ($i + 1), $menuItems[$i])
    }
    Write-Host " Q) Quit`n"
}

# 5) Main loop
do {
    Show-Menu
    $choice = Read-Host "Enter choice"
    if ($choice.ToUpper() -eq 'Q') {
        Write-Host "Exiting…"; break
    }
    elseif ($actions.ContainsKey($choice)) {
        & $actions[$choice]
        Read-Host "Press Enter to return to menu"
    }
    else {
        Write-Warning "Invalid choice. Please enter 1–$($menuItems.Count) or Q."
    }
} while ($true)

    
    
    
    
    
    }


      
    Default {
        Write-Host "`nInvalid choice. Please run the script again and select 1 or 2." -ForegroundColor Red
    }
}
