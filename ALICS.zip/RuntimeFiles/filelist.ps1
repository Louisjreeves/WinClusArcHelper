﻿$action1 = @{}

$action1['1'] = @(
      "C:\Observability\ALM",
      "C:\Observability\ALMSystemAgents",
      @{ Path = "C:\MASLogs"; Filter = "AgentLifeCycleManager_*" }
    )

    $action1['2'] = @(
      "C:\Observability\ALMSystemAgents\FileCopyAgent",
      "C:\Observability\ALMSystemAgents\FirewallAgent",
      "C:\Observability\ALMSystemAgents\Hypersync"
      )


    $action1['3'] = @(
      "C:\ProgramData\AzureConnectedMachineAgent\Log\*",
      "C:\ProgramData\AzureConnectedMachineAgent\*Log",
      "C:\Windows\System32\Bootstrap\Logs\*",
      "C:\Windows\System32\Bootstrap\Logs\AzStackHci.ArcConnection.Debug.log\*.txt",
      "C:\ProgramData\GuestConfig\ext_mgr_logs\*",
      "C:\ProgramData\GuestConfig\arc_policy_logs\*",
      "C:\ProgramData\GuestConfig\extension_logs\*",
      "C:\ProgramData\GuestConfig\extension_reports\*"
            )

    $action1['4'] = @(
            "C:\ProgramData\AzureConnectedMachineAgent\Log\*",
            "C:\ProgramData\AzureConnectedMachineAgent\*.Log",
            "C:\ProgramData\GuestConfig\ext_mgr_logs\*",
            "C:\ProgramData\GuestConfig\arc_policy_logs\*",
            "C:\ProgramData\GuestConfig\extension_logs\*",
            "C:\ProgramData\GuestConfig\extension_reports\*",
            "C:\Windows\System32\Bootstrap\Logs\*",
            "C:\Windows\System32\Bootstrap\DiagnosticsHistory\Bootstrap\*",
            "C:\Windows\System32\Bootstrap\DiagnosticsHistory\DiagnosticsResult-*.json",
            "C:\Windows\System32\Bootstrap\DiagnosticsHistory\PrerequisitesResult-*.json",
            "C:\Windows\System32\Bootstrap\DiagnosticsHistory\*",
            "C:\Windows\System32\Bootstrap\Telemetry\*",
            "C:\CloudDeployment\Logs\*",
            "C:\Windows\Setup\startupscript.log"
        )
    $action1['5'] = "C:\CloudDeployment\Logs\*"
    $action1['6'] = "C:\Windows\Logs\WindowsUpdate\*"
    $action1['7'] =  @(
            "C:\Windows\Logs\MoSetup\agentupdate.log",
            "C:\Windows\Logs\MoSetup\deviceinventory.xml",
            "C:\Windows\ServiceProfiles\Azure Stack HCI Download Service\*",
            "C:\Windows\SoftwareDistribution\Download\2d12f505042801c5c517655e4f65c8be\Metadata\DeviceInventory.xml"
        )


    $action1['8'] = @(
            "C:\ProgramData\AzureConnectedMachineAgent\Log\azcmagent*.*",
            "C:\ProgramData\AzureConnectedMachineAgent\Log\Arc-proxy*.*",
            "C:\ProgramData\AzureConnectedMachineAgent\Log\himds*.log"
        )


     $action1['9'] = @(
            "C:\ProgramData\mochostagent\log\*",
            "C:\ProgramData\wssdagent\log\Agent*",
            "C:\ProgramData\wssdagent\log\wssdagent.log",
            "C:\Observability\MOC_ARB\*.log",
            "C:\Observability\MOC_ARB\*.etl",
            "C:\Observability\MOC_ARB\*.zip"
        )

 $action1['10'] = $eceSources = @(
            "C:\Observability\ECE\*.zip",
            "C:\Observability\ECE\*.etl",
            "C:\Observability\ECEAgent\CommonInfra\*.etl",
            "C:\Observability\ECEAgent\CommonInfra\*.zip"
        )

 $action1['11'] = @(
            "C:\CloudContent\MASLogs\*.*",
            "C:\Observability\RemoteSupportAgent\*.etl"
        )

 $action1['12'] = @(
            "C:\ClusterStorage\Infrastructure_1\Shares\SU1_Infrastructure_1\Updates\HealthCheck\System\*",
            "C:\Observability\HealthAndMonitoring\Diagnostics\HealthService\*.etl",
            "C:\Observability\HealthAndMonitoring\Diagnostics\HealthService\*.zip"
        )
 $action1['13'] = @(
            "C:\Observability\NC\SDNDiagnostics\*.etl",
            "C:\Observability\NC\SDNDiagnostics\*.zip"
        )
 $action1['14'] = @(
            "C:\Observability\CommonInfra\Middleware\*.etl",
            "C:\Observability\CommonInfra\Middleware\*.zip"
        )
 $action1['15'] = @(
            "C:\MASLogs\LCMECELiteLogs\*.log",
            "C:\MASLogs\LCMECELiteLogs\*.xml"
        )
 $action1['16'] = @(
            "C:\Observability\HealthAndMonitoring\Diagnostics\HealthAgent\CommonInfra\*.etl",
            "C:\Observability\HealthAndMonitoring\Diagnostics\HealthAgent\CommonInfra\*.zip",
            "C:\Observability\HealthAndMonitoring\Diagnostics\HealthAgent\*.etl"
        )

